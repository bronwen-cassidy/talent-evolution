CREATE VIEW ZYNAP_USER_OU_PERMITS AS select  u.id as user_id, dp.node_id, dp.permit_id, dp.action
    from users u,subjects s,subject_primary_associations sa, positions p, ZYNAP_OU_DEFAULT_PERMITS dp
    where u.id = s.user_id and s.node_id = sa.subject_id and sa.position_id = p.node_id
    and p.org_unit_id = dp.root_id
    union
    select u.id as user_id, sdp.node_id, sdp.permit_id, sdp.action
    from users u , security_domains_users sdu, zynap_sd_ou_permits sdp
    where u.id = sdu.user_id and sdu.sd_id = sdp.sd_id
    union
    select u.id as user_id, sdp.node_id, sdp.permit_id, sdp.action
    from users u , security_domains_users sdu, sd_ou_exc_permits sdp
    where u.id = sdu.user_id and sdu.sd_id = sdp.sd_id


/
