CREATE VIEW ZYNAP_OU_DEFAULT_PERMITS AS SELECT root_id , node_id , permit_id, action from default_ouh_ou_permits dp
   where not exists
     ( select 1 from  sd_ou_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)


/
