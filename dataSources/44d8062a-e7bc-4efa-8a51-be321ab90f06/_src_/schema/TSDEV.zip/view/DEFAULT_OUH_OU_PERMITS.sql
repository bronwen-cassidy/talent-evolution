CREATE VIEW DEFAULT_OUH_OU_PERMITS AS SELECT oh.root_id as root_id ,oh.id as node_id , pt.id as
permit_id, pt.action as action
from permits_roles pr , roles r, permits pt , ou_hierarchy oh
  WHERE r.is_ounit_default='T' and r.id = pr.role_id and pr.permit_id = pt.id
and pt.content ='ORGANISATIONS'


/
