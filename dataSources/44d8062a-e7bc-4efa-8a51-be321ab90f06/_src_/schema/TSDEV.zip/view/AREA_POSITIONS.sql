CREATE VIEW AREA_POSITIONS AS SELECT ae.area_id as area_id, ph.id as node_id
 FROM area_elements ae, positions_hierarchy_inc ph
 WHERE ae.node_id=ph.root_id
 AND ae.is_excluded = 'F'
 AND ( ae.cascading='T' OR (ae.cascading <> 'T' AND ae.node_id = ph.id ))


/
