CREATE VIEW DEFAULT_PH_SUBJECT_PERMITS AS SELECT ph.root_id as root_id ,sa.subject_id as node_id , p.id as
 permit_id , p.action as action
 from permits_roles pr , roles r, permits p , positions_hierarchy ph,
  SUBJECT_PRIMARY_ASSOCIATIONS sa
 where
  sa.position_id = ph.id and
 r.is_position_default='T' and r.id = pr.role_id and pr.permit_id = p.id
 and p.content ='SUBJECTS'


/
