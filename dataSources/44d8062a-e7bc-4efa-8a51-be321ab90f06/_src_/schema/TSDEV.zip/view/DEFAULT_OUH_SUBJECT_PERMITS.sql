CREATE VIEW DEFAULT_OUH_SUBJECT_PERMITS AS select  oh.root_id as root_id ,sa.subject_id as node_id , pt.id as
permit_id , pt.action as action
from permits_roles pr , roles r, permits pt , ou_hierarchy oh, positions p,
SUBJECT_PRIMARY_ASSOCIATIONS sa
WHERE
p.org_unit_id = oh.id and
sa.position_id = p.node_id and
r.is_ounit_default='T' and r.id = pr.role_id and pr.permit_id = pt.id
and pt.content ='SUBJECTS'


/
