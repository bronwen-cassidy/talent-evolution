CREATE VIEW SEARCH_TERMS_XY AS select nd.id, nd.value as label, da.description, nd.node_id as artefact_id, dp.user_id, dp.permit_id,
          case
              when n.node_type = 'S' then 'subject link'
              when n.node_type = 'P' then 'position link'
              when node_type = 'O' then 'org_unit link'
          end as link_url,
          case
              when n.node_type = 'S' then
                (select first_name || ' ' || second_name from core_details cd, subjects s where s.node_id = nd.node_id and s.cd_id = cd.id)
              when n.node_type = 'P' then
                (select title from positions p where p.node_id = nd.node_id)
              when node_type = 'O' then
                (select label from organization_units o where o.node_id = nd.node_id)
          end as name,
          'T' as manager_read,
          'T' as individual_read
    from node_das nd, dynamic_attributes da, nodes n, user_node_domain_permits dp
    where da.type in ('TEXT', 'TEXTAREA', 'LINK', 'NUMBER', 'DOUBLE', 'DATE', 'DATETIME','TEXTBOX', 'INTEGER', 'NUMBER')
          and da.qd_id is null
          and nd.da_id = da.id
          and nd.node_id = dp.node_id
          and n.id = nd.node_id
          and n.node_type in ('S', 'P', 'O')
          and dp.node_id = n.id
    UNION
    -- all direct answers from dynamic_attributes of questionnaires
    select nd.id, nd.value as label, da.description, q.subject_id as artefact_id, dp.user_id, dp.permit_id, '' as link_url,
                  (select first_name || ' ' || second_name from core_details cd, subjects s where s.node_id = nd.node_id and s.cd_id = cd.id) as name
      ,
      qw.manager_read as manager_read,
      qw.INDIVIDUAL_READ as individual_read
    from node_das nd, dynamic_attributes da, nodes n, user_node_domain_permits dp, questionnaires q, que_workflows qw
    where da.type in ('TEXT', 'TEXTAREA', 'LINK', 'NUMBER', 'DOUBLE', 'DATE', 'DATETIME','TEXTBOX', 'INTEGER', 'NUMBER')
          and da.qd_id is not null
          and nd.da_id = da.id
          and nd.node_id = n.id
          and n.node_type = 'Q'
          and nd.node_id = q.node_id
          and q.subject_id = dp.node_id
          and q.qwf_id = qw.id
    UNION
    -- all select type answers from dynamic_attributes
    select nd.id, lv.short_desc as label, da.description, nd.node_id as artefact_id, dp.user_id, dp.permit_id,
                  case
                  when n.node_type = 'S' then 'subject link'
                  when n.node_type = 'P' then 'position link'
                  when node_type = 'O' then 'org_unit link'
                  end as link_url,
                  case
                  when n.node_type = 'S' then
                    (select first_name || ' ' || second_name from core_details cd, subjects s where s.node_id = nd.node_id and s.cd_id = cd.id)
                  when n.node_type = 'P' then
                    (select title from positions p where p.node_id = nd.node_id)
                  when node_type = 'O' then
                    (select label from organization_units o where o.node_id = nd.node_id)
                  end as name,
                  'T' as manager_read,
                  'T' as individual_read
    from node_das nd, dynamic_attributes da, nodes n, user_node_domain_permits dp, lookup_values lv
    where da.type in ('STRUCT', 'MULTISELECT')
          and da.qd_id is null
          and nd.value = to_char(lv.id)
          and nd.node_id = dp.node_id
          and n.node_type in ('S', 'P', 'O')
          and dp.node_id = n.id
    UNION
    -- all select type answers from dynamic_attributes
    select nd.id, lv.short_desc as label, da.description, q.subject_id as artefact_id, dp.user_id, dp.permit_id, 'questionnaire liunk_url' as link_url,
                  (select first_name || ' ' || second_name from core_details cd, subjects s where s.node_id = nd.node_id and s.cd_id = cd.id) as name
      ,
      qw.manager_read as manager_read,
      qw.INDIVIDUAL_READ as individual_read
    from node_das nd, dynamic_attributes da, nodes n, user_node_domain_permits dp, lookup_values lv, questionnaires q, que_workflows qw
    where da.type in ('STRUCT', 'MULTISELECT', 'RADIO', 'STATUS', 'CHECKBOX')
          and da.qd_id is not null
          and nd.value = to_char(lv.id)
          and nd.node_id = n.id
          and nd.node_id = q.node_id
          and n.node_type = 'Q'
          and q.qwf_id = qw.id
          and q.subject_id = dp.node_id
--WITH READ ONLY;
/
