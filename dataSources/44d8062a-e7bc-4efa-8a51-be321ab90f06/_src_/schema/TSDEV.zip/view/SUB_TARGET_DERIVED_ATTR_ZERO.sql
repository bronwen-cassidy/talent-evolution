CREATE VIEW SUB_TARGET_DERIVED_ATTR_ZERO AS select p.node_id, lv.id, 0
    from positions p, lookup_values lv
    where (lv.type_id = 'POSITIONSUBJECTASSOC' or lv.type_id = 'SECONDARYSUBJECTPOSASSOC')
and not exists
 ( select 1 from SUB_TARGET_DERIVED_ATTR_BASE stb where stb.node_id = p.node_id and stb.qualifier_id = lv.id)
--WITH READ ONLY;
/
