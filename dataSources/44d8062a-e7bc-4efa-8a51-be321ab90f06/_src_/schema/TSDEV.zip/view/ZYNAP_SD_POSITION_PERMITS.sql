CREATE VIEW ZYNAP_SD_POSITION_PERMITS AS SELECT sd_id , node_id , permit_id, action from sd_positions_permits dp
   where not exists
     ( select 1 from  sd_positions_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   and not exists
     ( select 1 from  sd_pos_ou_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   union all
   SELECT sd_id , node_id , permit_id, action from sd_pos_ou_permits dp
   where not exists
     ( select 1 from  sd_positions_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   and not exists
     ( select 1 from  sd_pos_ou_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)


/
