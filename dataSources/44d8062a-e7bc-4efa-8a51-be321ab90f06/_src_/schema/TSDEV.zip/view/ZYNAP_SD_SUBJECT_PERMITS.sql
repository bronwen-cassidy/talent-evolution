CREATE VIEW ZYNAP_SD_SUBJECT_PERMITS AS SELECT sd_id, node_id, permit_id, action from sd_subjects_permits dp
   where not exists
     ( select 1 from  sd_sub_ou_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   and not exists
     ( select 1 from  sd_sub_pos_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   and not exists
      ( select 1 from sd_subjects_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   union all
   SELECT sd_id, node_id, permit_id, action from sd_sub_pos_permits dp
   where not exists
      ( select 1 from  sd_sub_ou_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   and not exists
      ( select 1 from  sd_sub_pos_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   and not exists
      ( select 1 from sd_subjects_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   union all
   SELECT sd_id, node_id, permit_id, action from sd_sub_ou_permits dp
   where not exists
      ( select 1 from  sd_sub_ou_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   and not exists
      ( select 1 from  sd_sub_pos_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   and not exists
      ( select 1 from sd_subjects_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)


/
