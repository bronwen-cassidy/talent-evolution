CREATE VIEW AREA_POSITIONS_OU AS SELECT aou.area_id, p.node_id as node_id
 FROM AREA_OU aou, POSITIONS p
 WHERE p.org_unit_id = aou.node_id
 AND p.node_id NOT IN (
 	SELECT node_id
 	FROM area_elements
 	WHERE area_id=aou.area_id
 	AND is_excluded = 'T' )


/
