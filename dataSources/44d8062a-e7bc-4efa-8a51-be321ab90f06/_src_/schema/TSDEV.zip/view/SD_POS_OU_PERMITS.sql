CREATE VIEW SD_POS_OU_PERMITS AS SELECT sd.id as sd_id, ae.node_id, pt.id as permit_id, pt.action as action
 FROM area_positions_ou ae, security_domains sd, roles_security_domains  rsd, permits_roles pr, permits pt
 WHERE sd.is_exclusive='F'
 AND sd.node_id = ae.area_id
 AND sd.id = rsd.sd_id
 AND rsd.role_id =  pr.role_id
 AND pt.id = pr.permit_id
 AND pt.content = 'POSITIONS'


/
