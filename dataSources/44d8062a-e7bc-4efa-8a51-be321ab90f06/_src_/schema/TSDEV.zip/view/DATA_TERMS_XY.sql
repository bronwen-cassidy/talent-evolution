CREATE VIEW DATA_TERMS_XY AS select distinct (label), id from (
-- all direct answers from dynamic_attributes
      SELECT DISTINCT
        (nd.value) AS label, nd.id as id
      FROM node_das nd, dynamic_attributes da
      WHERE da.type IN ('TEXT', 'TEXTAREA', 'LINK', 'NUMBER', 'DOUBLE', 'DATE', 'DATETIME', 'TEXTBOX', 'INTEGER', 'NUMBER')
            AND da.qd_id IS NULL
            AND nd.da_id = da.id
      UNION
      -- all direct answers from dynamic_attributes of questionnaires
      SELECT DISTINCT
        (nd.value) AS label, nd.id as id
      FROM node_das nd, dynamic_attributes da, nodes n, questionnaires q
      WHERE da.type IN ('TEXT', 'TEXTAREA', 'LINK', 'NUMBER', 'DOUBLE', 'DATE', 'DATETIME', 'TEXTBOX', 'INTEGER', 'NUMBER')
            AND da.qd_id IS NOT NULL
            AND nd.da_id = da.id
            AND nd.node_id = n.id
            AND n.node_type = 'Q'
            AND nd.node_id = q.node_id
      UNION
      -- all select type answers from dynamic_attributes
      SELECT DISTINCT
        (lv.short_desc) AS label, nd.id as id
      FROM node_das nd, dynamic_attributes da, lookup_values lv
      WHERE da.type IN ('STRUCT', 'MULTISELECT')
            AND da.qd_id IS NULL
            AND nd.value = to_char(lv.id)
      UNION
      -- all select type answers from dynamic_attributes
      SELECT DISTINCT
        (lv.short_desc) AS label, nd.id as id
      FROM node_das nd, dynamic_attributes da, lookup_values lv, questionnaires q
      WHERE da.type IN ('STRUCT', 'MULTISELECT', 'RADIO', 'STATUS', 'CHECKBOX')
            AND da.qd_id IS NOT NULL
            AND nd.value = to_char(lv.id)
            AND nd.node_id = q.node_id)
--WITH READ ONLY;
/
