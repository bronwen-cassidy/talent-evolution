CREATE VIEW ZYNAP_POSITION_DA AS SELECT  c.da_id, c.node_id, a.label, a.type, a.max_size, a.min_size, a.is_mandatory, a.is_searchable, refers_to, c.value
  FROM dynamic_attributes a, node_das c
  WHERE a.is_active='T' AND a.artefact_type='P'
  AND a.id = c.da_id
--WITH READ ONLY;
/
