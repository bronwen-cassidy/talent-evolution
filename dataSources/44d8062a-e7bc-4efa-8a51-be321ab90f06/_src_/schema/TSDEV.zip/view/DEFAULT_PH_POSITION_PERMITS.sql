CREATE VIEW DEFAULT_PH_POSITION_PERMITS AS SELECT ph.root_id as root_id ,ph.id as node_id , p.id as
permit_id, p.action as action
from permits_roles pr , roles r, permits p , positions_hierarchy ph
  WHERE r.is_position_default='T' and r.id = pr.role_id and pr.permit_id = p.id
and p.content ='POSITIONS'


/
