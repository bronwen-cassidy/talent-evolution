CREATE VIEW POS_SOURCE_DERIVED_ATTR_ZERO AS select p.node_id, lv.id, 0
    from positions p, lookup_values lv
    where (lv.type_id = 'PRIMARY' or lv.type_id = 'SECONDARY')
and not exists
 ( select 1 from POS_SOURCE_DERIVED_ATTR_BASE psb where psb.node_id = p.node_id and psb.qualifier_id = lv.id)
--WITH READ ONLY;
/
