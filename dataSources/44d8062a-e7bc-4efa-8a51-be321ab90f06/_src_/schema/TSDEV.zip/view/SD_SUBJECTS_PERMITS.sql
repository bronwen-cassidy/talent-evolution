CREATE VIEW SD_SUBJECTS_PERMITS AS SELECT sd.id as sd_id, ae.node_id, pt.id as permit_id, pt.action as action
 from area_subjects ae, security_domains sd, roles_security_domains rsd, permits_roles pr, permits pt
 WHERE sd.is_exclusive='F'  and sd.node_id = ae.area_id
 and  sd.id = rsd.sd_id
 and  rsd.role_id =  pr.role_id
 and pt.id = pr.permit_id
 and pt.content = 'SUBJECTS'


/
