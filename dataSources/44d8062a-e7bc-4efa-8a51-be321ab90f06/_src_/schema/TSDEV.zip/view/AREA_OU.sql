CREATE VIEW AREA_OU AS SELECT ae.area_id as area_id, oh.id as node_id
  FROM area_elements ae,ou_hierarchy_inc oh
  WHERE ae.node_id=oh.root_id
  AND ae.is_excluded = 'F'
  AND (ae.cascading='T' OR (ae.cascading <>'T' AND oh.root_id = oh.id))


/
