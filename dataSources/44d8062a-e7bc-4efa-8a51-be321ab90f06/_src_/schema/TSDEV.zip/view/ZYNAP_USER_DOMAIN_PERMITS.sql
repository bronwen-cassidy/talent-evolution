CREATE VIEW ZYNAP_USER_DOMAIN_PERMITS AS select user_id, node_id, permit_id, action from ZYNAP_USER_POSITION_PERMITS
 union all
 select user_id, node_id, permit_id, action from ZYNAP_USER_OU_PERMITS
 union all
 select user_id, node_id, permit_id, action from ZYNAP_USER_SUBJECT_PERMITS


/
