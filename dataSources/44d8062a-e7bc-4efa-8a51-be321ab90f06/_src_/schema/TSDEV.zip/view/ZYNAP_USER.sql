CREATE VIEW ZYNAP_USER AS SELECT u.id, u.user_type, c.pref_given_name, c.first_name, c.second_name, c.title,
     u.is_active,
	l.username, l.password, l.expires, l.force_pwd_change
  FROM users u, logins l, subjects s, core_details c
  WHERE u.id = l.user_id  AND l.locked='F' AND  u.id (+) =s.user_id AND u.cd_id=c.id
--WITH READ ONLY;
/
