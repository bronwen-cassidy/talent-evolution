CREATE VIEW SUB_TARGET_DERIVED_ATTR_BASE AS select  position_id, value_id, count(*)
    from subject_associations group by position_id,value_id
--WITH READ ONLY;
/
