CREATE VIEW AREA_SUBJECTS_POS AS SELECT ae.area_id, sa.subject_id as node_id
from AREA_POSITIONS ae, SUBJECT_PRIMARY_ASSOCIATIONS sa
  WHERE ae.node_id = sa.position_id


/
