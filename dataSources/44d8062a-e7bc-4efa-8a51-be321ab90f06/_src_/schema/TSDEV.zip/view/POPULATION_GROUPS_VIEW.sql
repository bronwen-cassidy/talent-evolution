CREATE VIEW POPULATION_GROUPS_VIEW AS select p.ID,p.TYPE,p.USER_ID,p.LABEL,p.SCOPE,p.DESCRIPTION,p.ACTIVE_CRITERIA, pg.group_id from populations p left outer join population_groups pg on pg.population_id=p.id
--WITH READ ONLY;
/
