CREATE VIEW ZYNAP_SUBJECT AS SELECT u.id,  u.user_type, c.pref_given_name, c.first_name, c.second_name, c.title, u.is_active
  FROM users u, subjects s, core_details c
  WHERE u.id = s.user_id AND u.user_type IN ('SUBJECT', 'SYSTEMSUBJECT') AND s.cd_id=c.id
--WITH READ ONLY;
/
