CREATE VIEW POS_FILEITEM_AUTONOMY_VIEW AS SELECT
    pi.id, p.title, pi.node_id AS artefact_id, pi.owner_id,
     pi.label as content_title, NVL(pi.scope,'RESTRICTED') as scope,
    'P' as type, pi.content_type_id,
    pfi.blob_value as blob_value, pi.file_extension, pi.file_size
  FROM node_items pi, positions p, node_item_blobs pfi
  WHERE  pi.node_id = p.node_id
  AND pi.id=pfi.id
  AND pi.status='LIVE'
WITH READ ONLY


/
