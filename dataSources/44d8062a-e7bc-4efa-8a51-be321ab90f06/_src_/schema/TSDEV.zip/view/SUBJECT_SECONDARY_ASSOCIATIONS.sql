CREATE VIEW SUBJECT_SECONDARY_ASSOCIATIONS AS select sa."VALUE_ID",sa."ID",sa."POSITION_ID",sa."SUBJECT_ID",sa."COMMENTS" from subject_associations sa, lookup_values lv where
sa.value_id = lv.id and lv.type_id = 'SECONDARYSUBJECTPOSASSOC'
--WITH READ ONLY;
/
