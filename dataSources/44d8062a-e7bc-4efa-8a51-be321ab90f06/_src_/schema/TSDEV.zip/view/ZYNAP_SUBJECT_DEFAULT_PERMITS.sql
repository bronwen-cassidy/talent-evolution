CREATE VIEW ZYNAP_SUBJECT_DEFAULT_PERMITS AS SELECT root_id , node_id , permit_id, action from default_ouh_subject_permits dp
   where not exists
     ( select 1 from  sd_sub_ou_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   and not exists
     ( select 1 from  sd_sub_pos_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   and not exists
      ( select 1 from sd_subjects_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   union all
   SELECT root_id , node_id , permit_id, action from default_ph_subject_permits dp
   where not exists
     ( select 1 from  sd_sub_ou_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   and not exists
     ( select 1 from  sd_sub_pos_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)
   and not exists
      ( select 1 from sd_subjects_exc_permits where node_id = dp.node_id and permit_id = dp.permit_id)


/
