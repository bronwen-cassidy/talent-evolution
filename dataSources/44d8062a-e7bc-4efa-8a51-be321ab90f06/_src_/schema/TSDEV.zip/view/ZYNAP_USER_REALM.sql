CREATE VIEW ZYNAP_USER_REALM AS SELECT u.id, u.username, u.password
  FROM zynap_user u
  WHERE u.is_active = 'T'
--WITH READ ONLY;
/
