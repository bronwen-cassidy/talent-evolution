CREATE VIEW SUB_SOURCE_DERIVED_ATTR_BASE AS select  subject_id, value_id, count(*)
    from subject_associations group by subject_id,value_id
--WITH READ ONLY;
/
