CREATE VIEW SUBJECT_FILEITEM_AUTONOMY_VIEW AS SELECT
    si.id, c.first_name || ' ' || c.second_name AS title, si.node_id AS artefact_id,  si.owner_id,
      si.label AS content_title,
    NVL(si.scope,'RESTRICTED') as scope, 'S' as type, si.content_type_id,
    fi.blob_value as blob_value, si.file_extension, si.file_size
  FROM node_items si, node_item_blobs fi, subjects u, core_details c
  WHERE si.node_id = u.node_id
  AND u.cd_id=c.id
  AND si.id=fi.id
  AND si.status='LIVE'
WITH READ ONLY


/
