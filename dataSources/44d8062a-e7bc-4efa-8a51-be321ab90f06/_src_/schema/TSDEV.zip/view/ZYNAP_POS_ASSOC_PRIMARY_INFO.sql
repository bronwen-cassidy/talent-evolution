CREATE VIEW ZYNAP_POS_ASSOC_PRIMARY_INFO AS SELECT
  p.node_id,  p.title, p.org_unit_id, pa.id, 'PRIMARY' as type_id, pa.target_id as parent_position_id, pa.value_id as subtype_id
  FROM positions p, position_associations pa ,nodes n
  WHERE pa.source_id = n.id
  AND n.id = p.node_id
  AND pa.target_id = p.node_id
  AND n.is_active='T'
--WITH READ ONLY;
/
