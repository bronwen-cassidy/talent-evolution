CREATE VIEW POS_SOURCE_DERIVED_ATTR_BASE AS select  source_id, value_id, count(*)
    from position_associations group by source_id,value_id
--WITH READ ONLY;
/
