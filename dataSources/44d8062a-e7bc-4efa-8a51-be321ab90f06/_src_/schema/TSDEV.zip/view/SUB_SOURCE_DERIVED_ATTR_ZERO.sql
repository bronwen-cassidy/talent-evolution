CREATE VIEW SUB_SOURCE_DERIVED_ATTR_ZERO AS select s.node_id, lv.id, 0
    from subjects s, lookup_values lv
    where (lv.type_id = 'POSITIONSUBJECTASSOC' or lv.type_id = 'SECONDARYSUBJECTPOSASSOC')
and not exists
 ( select 1 from SUB_SOURCE_DERIVED_ATTR_BASE ssb where ssb.node_id = s.node_id and ssb.qualifier_id = lv.id)
--WITH READ ONLY;
/
