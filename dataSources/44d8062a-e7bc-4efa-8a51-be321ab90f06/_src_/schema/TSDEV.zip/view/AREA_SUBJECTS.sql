CREATE VIEW AREA_SUBJECTS AS SELECT ae.area_id as area_id, s.node_id as node_id
from area_elements ae, subjects s
  WHERE ae.node_id=s.node_id


/
