CREATE VIEW POS_TARGET_DERIVED_ATTR_BASE AS select  target_id, value_id, count(*)
    from position_associations group by target_id,value_id
--WITH READ ONLY;
/
