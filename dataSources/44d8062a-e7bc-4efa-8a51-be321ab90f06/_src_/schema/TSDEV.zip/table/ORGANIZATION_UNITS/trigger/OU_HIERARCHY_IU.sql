CREATE TRIGGER OU_HIERARCHY_IU
AFTER INSERT OR UPDATE
  ON ORGANIZATION_UNITS
FOR EACH ROW
  BEGIN
 if INSERTING then
     zynap_hierarchy_sp.insert_ou_hi(:NEW.node_id,:NEW.parent_id);
 end if;
if UPDATING AND NOT (:NEW.parent_id = :OLD.parent_id )then
    zynap_hierarchy_sp.update_ou_hi(:NEW.node_id,:NEW.parent_id);
end if;

END OU_HIERARCHY_IU;
/
