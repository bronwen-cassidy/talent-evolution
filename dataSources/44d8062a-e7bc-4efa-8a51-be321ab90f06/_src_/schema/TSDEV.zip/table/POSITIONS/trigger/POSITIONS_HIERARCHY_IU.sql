CREATE TRIGGER POSITIONS_HIERARCHY_IU
AFTER INSERT OR UPDATE
  ON POSITIONS
FOR EACH ROW
  BEGIN
 if INSERTING then
    zynap_hierarchy_sp.insert_position_hi(:NEW.node_id,:NEW.parent_id);
 end if;
if UPDATING AND NOT (:NEW.parent_id = :OLD.parent_id )then
    zynap_hierarchy_sp.update_position_hi(:NEW.node_id,:NEW.parent_id);
end if;

END POSITIONS_HIERARCHY;
/
