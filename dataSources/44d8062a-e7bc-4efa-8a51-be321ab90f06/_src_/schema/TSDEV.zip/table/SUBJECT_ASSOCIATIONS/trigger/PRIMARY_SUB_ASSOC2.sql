CREATE TRIGGER PRIMARY_SUB_ASSOC2
BEFORE DELETE
  ON SUBJECT_ASSOCIATIONS
FOR EACH ROW
  declare flag_ integer;
 BEGIN
     IF (zynap_hierarchy_sp.isSubPrimaryAssociation(:OLD.value_id)) THEN

        delete from subject_primary_associations where id = :OLD.id;
        select count(*) into flag_ from subject_primary_associations sa  where sa.subject_id = :OLD.subject_id;
        IF flag_ < 1 THEN
        	insert into area_elements (ID,AREA_ID,NODE_ID,CASCADING) VALUES (ASSOC_SQ.NEXTVAL,-2, :OLD.SUBJECT_ID, 'F');
        END IF;

        zynap_node_sp.update_delete_holder_info(:OLD.POSITION_ID, :OLD.SUBJECT_ID);
        zynap_node_sp.update_delete_job_info(:OLD.SUBJECT_ID, :OLD.POSITION_ID);

     END IF;

END PRIMARY_SUB_ASSOC2;
/
