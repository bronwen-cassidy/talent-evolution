CREATE TRIGGER PRIMARY_SUB_ASSOC
AFTER INSERT OR UPDATE
  ON SUBJECT_ASSOCIATIONS
FOR EACH ROW
  declare flag_ integer;

BEGIN

 if INSERTING AND (zynap_hierarchy_sp.isSubPrimaryAssociation(:NEW.value_id)) then

    INSERT INTO SUBJECT_PRIMARY_ASSOCIATIONS (ID,VALUE_ID,POSITION_ID,SUBJECT_ID)
    VALUES(:NEW.ID,:NEW.VALUE_ID,:NEW.POSITION_ID,:NEW.SUBJECT_ID);

 end if;

 if UPDATING then

    delete SUBJECT_PRIMARY_ASSOCIATIONS where ID = :NEW.ID;
    if (zynap_hierarchy_sp.isSubPrimaryAssociation(:NEW.value_id)) then

    	INSERT INTO SUBJECT_PRIMARY_ASSOCIATIONS (ID,VALUE_ID,POSITION_ID,SUBJECT_ID)
        VALUES(:NEW.ID,:NEW.VALUE_ID,:NEW.POSITION_ID,:NEW.SUBJECT_ID);

        select count(*) into flag_ from subject_primary_associations sa  where sa.subject_id = :OLD.subject_id;
        IF flag_ < 1 THEN
        	insert into area_elements (ID,AREA_ID,NODE_ID,CASCADING) VALUES (ASSOC_SQ.NEXTVAL,-2, :OLD.SUBJECT_ID, 'F');
        	zynap_node_sp.update_delete_holder_info(:OLD.POSITION_ID, :OLD.SUBJECT_ID);
        	zynap_node_sp.update_delete_job_info(:OLD.SUBJECT_ID, :OLD.POSITION_ID);
        END IF;

        zynap_node_sp.update_current_holder_info(:NEW.POSITION_ID);
        zynap_node_sp.update_current_holder_info(:OLD.POSITION_ID);
        zynap_node_sp.update_current_job_info(:NEW.SUBJECT_ID);
        zynap_node_sp.update_current_job_info(:OLD.SUBJECT_ID);

    end if;

end if;

END PRIMARY_SUB_ASSOC;
/
