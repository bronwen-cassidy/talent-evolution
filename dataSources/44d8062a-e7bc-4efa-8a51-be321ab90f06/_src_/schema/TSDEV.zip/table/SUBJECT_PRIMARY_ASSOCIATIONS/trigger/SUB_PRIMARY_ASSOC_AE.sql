CREATE TRIGGER SUB_PRIMARY_ASSOC_AE
AFTER INSERT OR DELETE
  ON SUBJECT_PRIMARY_ASSOCIATIONS
FOR EACH ROW
  declare
 flag_  integer;
 comp_ boolean;
 BEGIN
 if INSERTING then
    delete from area_elements where area_id = -2 and node_id = :NEW.SUBJECT_ID;
 end if;
 comp_ := true;
END SUB_PRIMARY_ASSOC_AE;
/
