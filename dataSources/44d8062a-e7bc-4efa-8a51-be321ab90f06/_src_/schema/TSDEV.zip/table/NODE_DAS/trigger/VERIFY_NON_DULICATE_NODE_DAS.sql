CREATE TRIGGER VERIFY_NON_DULICATE_NODE_DAS
BEFORE INSERT
  ON NODE_DAS
FOR EACH ROW
  declare flag_ integer;
  datype_ varchar2 (100);
  dynamic_ varchar2 (2);

  BEGIN

    SELECT TYPE INTO datype_ FROM DYNAMIC_ATTRIBUTES WHERE ID = :NEW.DA_ID;
    SELECT IS_DYNAMIC INTO dynamic_ FROM DYNAMIC_ATTRIBUTES WHERE ID = :NEW.DA_ID;

    IF(dynamic_ = 'F') THEN
        IF (datype_ NOT IN ('MULTISELECT', 'COMMENTS')) THEN
            -- this is a single valued type so there should be no existing values for the da_id and node_id in the database if there is we need to delete it
            SELECT COUNT(*) INTO flag_ FROM NODE_DAS WHERE DA_ID = :NEW.DA_ID AND NODE_ID = :NEW.NODE_ID;
            IF(flag_ > 0) THEN
                DELETE FROM NODE_DAS WHERE DA_ID = :NEW.DA_ID AND NODE_ID = :NEW.NODE_ID;
            END IF;
        END IF;
    END IF;

END VERIFY_NON_DULICATE_NODE_DAS;
/
