CREATE TRIGGER SUBJECTS_AE
AFTER INSERT OR DELETE
  ON SUBJECTS
FOR EACH ROW
  BEGIN
 if INSERTING then
    insert into area_elements (ID,AREA_ID,NODE_ID,CASCADING) VALUES (ASSOC_SQ.NEXTVAL,-2, :NEW.NODE_ID, 'F');
 end if;
 if DELETING then
    delete from area_elements where area_id = -2 and node_id = :OLD.NODE_ID;
 end if;
END SUBJECTS_AE;
/
