RegexPlugin - README

Installing RegexPlugin
========================

Use the pluginmanager.

Uninstalling RegexPlugin
==========================

Use the pluginmanager.

